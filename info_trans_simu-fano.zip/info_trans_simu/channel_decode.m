function decoded_bits = channel_decode(bits_in)
    % 确保输入是列向量，且格式必须是 0 和 1 (硬判决要求)
    bits_in = double(bits_in(:));
    
    % 与编码端一致的网格结构
    trellis = poly2trellis(7, [171 133]);
    
    % 回溯长度
    traceBack = 32; 
    
    % 使用维特比译码 (Viterbi Decoding)
    % 'term'：终端模式
    % 'hard'：硬判决模式，明确告诉算法输入已经是纯粹的 0 和 1
    decoded_padded = vitdec(bits_in, trellis, traceBack, 'term', 'hard');
    
    % 剔除掉我们在编码时人为添加的 6 个冲刷零
    decoded_bits = decoded_padded(1 : end-6);
end