function [encoded_bits, pad_len] = hamming_encode(input_bits, n, k)
%HAMMING_ENCODE Encode a bit stream with a general Hamming(n,k) code.
%   n must satisfy n = 2^m - 1 and k = n - m.

bits = normalize_bits(input_bits);
if numel(bits) == 0
    encoded_bits = zeros(1, 0);
    pad_len = 0;
    return;
end

m = n - k;
if n <= 0 || k <= 0 || m <= 0 || n ~= 2^m - 1 || k ~= n - m
    error('hamming_encode:InvalidParameters', 'Invalid Hamming parameters n=%d, k=%d.', n, k);
end

pad_len = mod(k - mod(numel(bits), k), k);
if pad_len > 0
    bits = [bits, zeros(1, pad_len)];
end

data_blocks = reshape(bits, k, []).';
num_blocks = size(data_blocks, 1);
encoded_blocks = zeros(num_blocks, n);
parity_positions = 2 .^ (0:m-1);
data_positions = setdiff(1:n, parity_positions);
encoded_blocks(:, data_positions) = data_blocks;

for i = 1:m
    parity_pos = parity_positions(i);
    positions = bitget(1:n, i) == 1;
    positions(parity_pos) = false;
    encoded_blocks(:, parity_pos) = mod(sum(encoded_blocks(:, positions), 2), 2);
end

encoded_bits = reshape(encoded_blocks.', 1, []);
encoded_bits = double(encoded_bits);
end

function [decoded_bits, corrected_codewords] = hamming_decode(received_bits, n, k, total_data_bits)
%HAMMING_DECODE Decode a Hamming(n,k) bit stream, correcting single-bit errors.
%   If total_data_bits is provided, the decoded output is truncated to that length.

bits = normalize_bits(received_bits);
if isempty(bits)
    decoded_bits = zeros(1, 0);
    corrected_codewords = zeros(0, n);
    return;
end

if mod(numel(bits), n) ~= 0
    error('hamming_decode:InvalidLength', 'Received bit stream length must be a multiple of %d.', n);
end

m = n - k;
parity_positions = 2 .^ (0:m-1);
code_blocks = reshape(bits, n, []).';
num_blocks = size(code_blocks, 1);

syndromes = zeros(num_blocks, m);
for i = 1:m
    positions = bitget(1:n, i) == 1;
    syndromes(:, i) = mod(sum(code_blocks(:, positions), 2), 2);
end

error_positions = sum(syndromes .* (2 .^ (0:m-1)), 2);
corrected_codewords = code_blocks;
for idx = 1:num_blocks
    if error_positions(idx) > 0
        corrected_codewords(idx, error_positions(idx)) = 1 - corrected_codewords(idx, error_positions(idx));
    end
end

data_positions = setdiff(1:n, parity_positions);
decoded_data = reshape(corrected_codewords(:, data_positions).', 1, []);
if nargin >= 4 && ~isempty(total_data_bits) && total_data_bits < numel(decoded_data)
    decoded_bits = decoded_data(1:total_data_bits);
else
    decoded_bits = decoded_data;
end

decoded_bits = double(decoded_bits);
end

function bits = normalize_bits(input_bits)
bits = double(input_bits(:).');
if any(bits ~= 0 & bits ~= 1)
    error('hamming_code:InvalidInput', 'Input must be a 0/1 bit stream.');
end
end