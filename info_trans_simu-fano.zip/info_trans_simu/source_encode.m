function [encoded_bits, fano_dict] = source_encode(bits_in)
    % 1. 将 0/1 比特流每 8 位还原为一个像素符号 (0-255)
    bits_reshaped = reshape(bits_in, 8, []).';
    symbols_dec = bin2dec(char(bits_reshaped + '0')); 

    % 2. 统计每个符号出现的频次和概率
    unique_symbols = unique(symbols_dec);
    counts = histcounts(symbols_dec, [unique_symbols; max(unique_symbols)+1]);
    probs = counts / sum(counts);

    % 3. 按概率降序排列（费诺码的要求）
    [sorted_probs, sort_idx] = sort(probs, 'descend');
    sorted_symbols = unique_symbols(sort_idx);

    % 4. 递归生成费诺码字典
    fano_dict = cell(length(sorted_symbols), 2);
    for i = 1:length(sorted_symbols)
        fano_dict{i, 1} = sorted_symbols(i);
        fano_dict{i, 2} = []; % 初始码字为空
    end
    fano_dict = generate_fano_recursive(fano_dict, 1, length(sorted_symbols), sorted_probs);

    % 5. 纯手写执行编码 (不再依赖工具箱)
    % 创建快速查找表 (基于像素值 0-255)
    lookup = cell(256, 1);
    for i = 1:size(fano_dict, 1)
        lookup{fano_dict{i, 1} + 1} = fano_dict{i, 2}; % 像素值+1作为索引
    end
    
    % 将所有符号映射为对应的比特序列，并拼接所有比特
    encoded_cell = lookup(symbols_dec + 1);
    encoded_bits = [encoded_cell{:}].'; % 展平为一维列向量
end

% --- 费诺码核心递归分割算法 (保持不变) ---
function dict = generate_fano_recursive(dict, start_idx, end_idx, probs)
    if start_idx >= end_idx
        return;
    end
    min_diff = inf;
    split_idx = start_idx;
    for i = start_idx : end_idx - 1
        sum_left = sum(probs(start_idx : i));
        sum_right = sum(probs(i + 1 : end_idx));
        diff = abs(sum_left - sum_right);
        if diff < min_diff
            min_diff = diff;
            split_idx = i;
        end
    end
    for i = start_idx : split_idx
        dict{i, 2} = [dict{i, 2}, 0];
    end
    for i = split_idx + 1 : end_idx
        dict{i, 2} = [dict{i, 2}, 1];
    end
    dict = generate_fano_recursive(dict, start_idx, split_idx, probs);
    dict = generate_fano_recursive(dict, split_idx + 1, end_idx, probs);
end