% =========================================================
% 哈夫曼编码 (Huffman Coding) 算法流程图自动生成脚本 (终极兼容版)
% =========================================================
clc; clear; close all;

% 1. 创建画布并设置属性
fig = figure('Name', '哈夫曼编码算法流程图', 'Color', 'w', 'Position', [250, 100, 600, 750]);
axis off; 
hold on;
xlim([0, 10]);
ylim([0, 100]);

% 2. 定义流程图框的坐标与尺寸
box_width = 7.8;
box_height = 8.5;
center_x = 5;
y_start = 88;
y_spacing = 15;

% 【彻底解决颜色报错】：全部使用 RGB 数组，完美兼容所有老版本 MATLAB
color_orange = [0.8500, 0.3250, 0.0980];  % 经典橙色
color_bg = [1.0000, 0.9500, 0.9000];      % 浅橙背景色
color_black = [0, 0, 0];                  % 纯黑

% 【彻底解决转义警告】：使用 \\geq 确保 sprintf 安全解析
steps = {
    '1. 统计信源符号出现概率', ...
    '2. 将符号按概率从大到小降序排列\n(p_1 \\geq p_2 \\geq ... \\geq p_n)', ...
    '3. 选取概率最小的两个节点合并为新节点，\n概率相加，并向两分支分别分配 0 和 1', ...
    '4. 将新节点的概率加入原序列并重新降序排列，\n重复步骤 3，直至根节点总概率为 1', ...
    '5. 逆向回溯：从根节点沿着路径走到叶子节点，\n读取路径上的 0 和 1，生成最终变长码字'
};

% 3. 循环绘制矩形框和文本
y_positions = zeros(1, length(steps));
for i = 1:length(steps)
    % 计算当前框的 Y 坐标
    y_pos = y_start - (i-1) * y_spacing;
    y_positions(i) = y_pos;
    
    % 绘制圆角矩形 (使用 RGB 数组)
    rectangle('Position', [center_x - box_width/2, y_pos - box_height/2, box_width, box_height], ...
              'Curvature', 0.2, 'FaceColor', color_bg, 'EdgeColor', color_orange, 'LineWidth', 1.5);
          
    % 插入文本 
    text(center_x, y_pos, sprintf(steps{i}), ...
         'HorizontalAlignment', 'center', ...
         'VerticalAlignment', 'middle', ...
         'FontSize', 12, 'FontWeight', 'bold', 'Color', color_black, 'Interpreter', 'tex');
end

% 4. 绘制框与框之间的连接箭头
for i = 1:length(steps)-1
    % 箭头起点与终点
    x1 = center_x;
    y1 = y_positions(i) - box_height/2;
    x2 = center_x;
    y2 = y_positions(i+1) + box_height/2;
    
    % 画直线
    plot([x1, x2], [y1, y2], 'k-', 'LineWidth', 1.5);
    
    % 画箭头尖端 (使用 RGB 颜色规避 fill 报错)
    arrow_size = 1.2;
    fill([x2, x2-arrow_size/2, x2+arrow_size/2], [y2, y2+arrow_size, y2+arrow_size], color_black, 'EdgeColor', 'none');
end

% 5. 绘制代表"重复循环"的侧边反馈箭头 (从步骤4指向步骤3)
x_side = center_x + box_width/2 + 0.8;
y_step4 = y_positions(4);
y_step3 = y_positions(3);

plot([center_x + box_width/2, x_side], [y_step4, y_step4], '--', 'LineWidth', 1.5, 'Color', color_orange); % 横出
plot([x_side, x_side], [y_step4, y_step3], '--', 'LineWidth', 1.5, 'Color', color_orange);                 % 向上
plot([x_side, center_x + box_width/2], [y_step3, y_step3], '--', 'LineWidth', 1.5, 'Color', color_orange); % 横入

% 反馈箭头尖端 (使用 RGB 颜色规避 fill 报错)
fill([center_x + box_width/2, center_x + box_width/2 + arrow_size, center_x + box_width/2 + arrow_size], ...
     [y_step3, y_step3 + arrow_size/2, y_step3 - arrow_size/2], color_orange, 'EdgeColor', 'none');
 
text(x_side + 0.2, (y_step4 + y_step3)/2, '循环合并', 'FontSize', 11, 'Color', color_orange, 'FontWeight', 'bold', 'Rotation', 90, 'HorizontalAlignment', 'center');

% 添加总标题
text(center_x, y_start + 8, '哈夫曼编码 (Huffman Coding) 核心算法流程', ...
     'HorizontalAlignment', 'center', 'FontSize', 15, 'FontWeight', 'bold', 'Color', color_orange);

hold off;
fprintf('✅ 哈夫曼编码流程图已完美生成！所有老版本兼容性报错均已消除！\n');