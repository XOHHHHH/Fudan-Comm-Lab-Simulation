function decoded_bits = source_decode(encoded_bits, fano_dict)
    % 修复版：纯手写前缀码解码树
    
    % 1. 根据字典构建二叉解码树
    MAX_NODES = length(fano_dict) * 30; 
    tree = zeros(MAX_NODES, 2);
    node_cnt = 1; % 根节点索引为1
    
    for i = 1:size(fano_dict, 1)
        sym = fano_dict{i, 1};
        code = fano_dict{i, 2};
        curr_node = 1;
        
        % 【关键修复】：遍历到倒数第二个比特，建立路径节点
        for j = 1:length(code)-1 
            bit = code(j);
            if bit == 0
                if tree(curr_node, 1) == 0
                    node_cnt = node_cnt + 1;
                    tree(curr_node, 1) = node_cnt;
                end
                curr_node = tree(curr_node, 1);
            else
                if tree(curr_node, 2) == 0
                    node_cnt = node_cnt + 1;
                    tree(curr_node, 2) = node_cnt;
                end
                curr_node = tree(curr_node, 2);
            end
        end
        
        % 【关键修复】：最后一个比特直接指向负数的符号值（真正的叶子节点）
        if ~isempty(code)
            last_bit = code(end);
            if last_bit == 0
                tree(curr_node, 1) = -(sym + 1); 
            else
                tree(curr_node, 2) = -(sym + 1);
            end
        end
    end
    
    % 2. 遍历输入的比特流进行解码
    num_bits = length(encoded_bits);
    decoded_symbols = zeros(ceil(num_bits/2), 1); 
    sym_idx = 1;
    curr_node = 1;
    
    for i = 1:num_bits
        bit = encoded_bits(i);
        if bit == 0
            curr_node = tree(curr_node, 1);
        else
            curr_node = tree(curr_node, 2);
        end
        
        if curr_node < 0 % 遇到叶子节点，成功解出一个符号
            decoded_symbols(sym_idx) = -curr_node - 1; 
            sym_idx = sym_idx + 1;
            curr_node = 1; % 瞬间回到根节点，绝不吞噬下一个比特！
        end
    end
    
    decoded_symbols = decoded_symbols(1:sym_idx-1); 
    
    % 3. 将还原出的十进制符号 (0-255) 重新转回 8 位比特流
    bin_str = dec2bin(decoded_symbols, 8);
    decoded_bits = bin_str.' - '0';
    decoded_bits = decoded_bits(:);
end