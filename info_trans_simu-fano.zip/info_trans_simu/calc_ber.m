function ber = calc_ber(tx_bits, rx_bits)
    % 计算误码率 (Bit Error Rate)
    % 确保两者长度一致，取最短长度比较（防溢出保护）
    len = min(length(tx_bits), length(rx_bits));
    err_count = sum(tx_bits(1:len) ~= rx_bits(1:len));
    ber = err_count / len;
end