% ==========================================
% 信息传输全链路仿真流程图绘制脚本
% ==========================================
clc; clear; close all;

% 1. 定义流程节点名称 (包含你选定的所有技术细节)
node_names = {
    '1. 读取输入图像'
    '2. 图像转比特流'
    '3. 信源编码 (费诺码递归切分)'
    '4. 信道编码 (卷积码 171,133 | K=7, R=1/2)'
    '5. BPSK 调制'
    '6. AWGN 信道 (叠加高斯白噪声)'
    '7. BPSK 解调 (硬判决)'
    '8. 信道译码 (维特比译码 Viterbi)'
    '9. 信源译码 (费诺解码树)'
    '10. 恢复比特流重构图像'
    '11. 计算误码率 (BER) 与图像质量评估'
};

% 2. 定义节点之间的连接关系 (起点 source -> 终点 target)
% 主链路：1 -> 2 -> 3 -> 4 -> 5 -> 6 -> 7 -> 8 -> 9 -> 10 -> 11
s = 1:10;
t = 2:11;

% 创建有向图对象
G = digraph(s, t, [], node_names);

% 3. 添加一条虚线连接：从"2"直接到"11"，代表原始比特流用于对比计算BER
G = addedge(G, 2, 11);

% 4. 绘制流程图
figure('Name', '全链路仿真流程图', 'Position', [100, 100, 600, 800], 'Color', 'w');
h = plot(G, 'Layout', 'layered', 'Direction', 'down');

% 5. 美化图表样式
h.NodeFontSize = 11;
h.NodeFontWeight = 'bold';
h.NodeColor = [0.1, 0.3, 0.6];    % 节点文字颜色（深蓝）
h.MarkerSize = 8;
h.Marker = 's';                   % 方形节点
h.EdgeColor = [0.4, 0.4, 0.4];    % 连线颜色
h.LineWidth = 1.5;
h.ArrowSize = 12;

% 单独将 2->11 的对比线设置为红色虚线（表示参照对比）
edge_idx = findedge(G, 2, 11);
highlight(h, 'Edges', edge_idx, 'EdgeColor', 'r', 'LineStyle', '--');

title('信息传输全链路仿真系统架构', 'FontSize', 16, 'FontWeight', 'bold');
axis off; % 隐藏坐标轴