% ==========================================
% 费诺压缩 + 卷积码 (硬判决数据导出 & 软硬判决对比瀑布曲线)
% ==========================================
clc; clear; close all;

%% 1. 准备硬判决实验数据并导出到 Excel
SNR_hard = [1; 3; 5; 6; 7];
R_total = [0.5546; 0.5546; 0.5546; 0.5546; 0.5546];
Channel_BER = [0.130501; 0.078820; 0.037648; 0.023117; 0.012586];
Final_BER = [0.464695; 0.464931; 0.284063; 0.317986; 0.000000];
PER = [0.988327; 0.985443; 0.714081; 0.863831; 0.000000];
PSNR = ["12.14"; "12.30"; "18.89"; "23.25"; "Inf"];
Observation = ["失步严重，比特流膨胀"; "失步严重，比特流膨胀"; "失步严重，比特流膨胀"; "纠错改善，缩水 8 bit"; "完美解码，无失步"];

results_table = table(SNR_hard, R_total, Channel_BER, Final_BER, PER, PSNR, Observation, ...
    'VariableNames', {'信噪比_SNR_dB', '传输效率_R_total', '信道物理误码率_Channel_BER', ...
                      '最终误码率_BER', '像素错误率_PER', '峰值信噪比_PSNR_dB', '观察现象_失步情况'});

filename = 'Fano_Conv_Hard_Results.xlsx';
writetable(results_table, filename);
fprintf('✅ 数据已成功导出到 Excel 文件: %s\n', filename);

%% 2. 绘制软硬判决对比瀑布曲线
% 提取用于画图的对数 BER 数据 (把 0 替换为 1e-6)
ber_hard_plot = [0.464695, 0.464931, 0.284063, 0.317986, 1e-6]; 

% 引入上一次的软判决数据用于同屏对比
snr_soft = [1, 3, 5];
ber_soft_plot = [0.462475, 0.399193, 1e-6]; 

figure('Name', '卷积码软硬判决对比性能', 'Color', 'w', 'Position', [150, 150, 800, 550]);

% 绘制硬判决曲线 (红色虚线)
semilogy(SNR_hard, ber_hard_plot, '--o', 'LineWidth', 2.5, 'MarkerSize', 10, ...
    'MarkerFaceColor', '#D95319', 'Color', '#D95319', 'DisplayName', '硬判决 Viterbi (丢失幅度置信度)');
hold on;

% 绘制软判决曲线 (蓝色实线)
semilogy(snr_soft, ber_soft_plot, '-p', 'LineWidth', 2.5, 'MarkerSize', 12, ...
    'MarkerFaceColor', '#0072BD', 'Color', '#0072BD', 'DisplayName', '软判决 Viterbi (利用欧氏距离)');

% 图表美化与网格设置
grid on;
set(gca, 'YMinorGrid', 'on', 'GridAlpha', 0.4, 'FontSize', 12);
xlabel('信噪比 SNR (dB)', 'FontSize', 13, 'FontWeight', 'bold');
ylabel('误码率 BER (Log Scale)', 'FontSize', 13, 'FontWeight', 'bold');
title('费诺压缩系统下：卷积码软/硬判决性能对比', 'FontSize', 15, 'FontWeight', 'bold');

xlim([0, 8]);
ylim([1e-6, 1]);
yticks(logspace(-6, 0, 7));

% 添加图例
legend('Location', 'southwest', 'FontSize', 12, 'FontWeight', 'bold');

% 标注崖点与 2dB 理论编码增益
text(7, 1e-6, ' 硬判决崖点 (7dB)', 'VerticalAlignment', 'bottom', ...
    'HorizontalAlignment', 'right', 'FontSize', 11, 'Color', '#D95319', 'FontWeight', 'bold');

text(5, 1e-6, ' 软判决崖点 (5dB)', 'VerticalAlignment', 'bottom', ...
    'HorizontalAlignment', 'right', 'FontSize', 11, 'Color', '#0072BD', 'FontWeight', 'bold');

annotation('doublearrow', [0.635 0.79], [0.11 0.11], 'Color', 'k', 'LineWidth', 1.5);
text(6, 3e-6, '理论 2dB 编码增益差异', 'HorizontalAlignment', 'center', 'FontSize', 11, 'FontWeight', 'bold');

hold off;