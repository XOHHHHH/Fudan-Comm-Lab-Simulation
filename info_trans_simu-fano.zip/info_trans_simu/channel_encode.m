function encoded_bits = channel_encode(bits_in)
    % 确保输入是列向量
    bits_in = bits_in(:);
    
    % 采用标准卷积码：约束长度 K=7, 生成多项式 [171, 133] (八进制)
    trellis = poly2trellis(7, [171 133]);
    
    % 物理机制：尾比特冲刷 (Flushing)
    % 卷积编码器包含 6 个延迟寄存器 (K-1 = 6)。
    % 为了让译码器在最后能完全收敛并吐出所有状态，我们在信息比特末尾人为添加 6 个 0
    bits_padded = [bits_in; zeros(6, 1)];
    
    % 进行卷积编码
    encoded_bits = convenc(bits_padded, trellis);
end