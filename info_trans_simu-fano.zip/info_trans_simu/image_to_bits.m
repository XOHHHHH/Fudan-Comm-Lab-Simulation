function bits = image_to_bits(img)
    % 高效将图像矩阵转为 1 维比特流
    bin_str = dec2bin(img(:), 8); % 转为 8 位二进制字符串矩阵
    bits = bin_str.' - '0';       % 转置后减去 ASCII '0' 转为数值
    bits = bits(:);               % 展平为列向量
end