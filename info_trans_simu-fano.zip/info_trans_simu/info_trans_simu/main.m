clc; clear; close all;

%% =========================
%  信息论课程项目主程序
%  功能：
%  1. 读取输入图像
%  2. 将图像转换为比特流
%  3. 进行信源编码
%  4. 进行信道编码
%  5. BPSK调制
%  6. 通过AWGN信道
%  7. BPSK解调判决
%  8. 进行信道译码
%  9. 进行信源译码
% 10. 将恢复后的比特流重构为图像
% 11. 计算误码率 BER
%% =========================


%% =========================
%  1. 参数设置
%% =========================

% 输入图像路径
img_path = 'test.png';
% AWGN信道信噪比（单位：dB）
snr_db = 5;
% 是否启用信源编码
use_source_coding = false;
% 是否启用信道编码
use_channel_coding = false;


%% =========================
%  2. 读取图像
%% =========================
img = imread(img_path);
% 如果输入是彩色图像，则转为灰度图
if ndims(img) == 3
    img = rgb2gray(img);
end
% 获取图像尺寸，后续重构图像时要用
img_size = size(img);
% 显示原图
figure;
imshow(img);
title('原始图像');


%% =========================
%  3. 图像转比特流
%% =========================

% 将灰度图像转为一维比特流
% 每个像素8比特，因此最终输出是0/1序列
tx_bits_original = image_to_bits(img);
% 保存原始比特流长度
original_bit_len = length(tx_bits_original);
fprintf('原始比特流长度：%d bit\n', original_bit_len);


%% =========================
%  4. 信源编码
%% =========================

if use_source_coding
   %%待写
    tx_bits_after_source = source_encode(tx_bits_original);
    fprintf('已启用信源编码。\n');
else
    tx_bits_after_source = tx_bits_original;
    fprintf('未启用信源编码。\n');
end

fprintf('信源编码后比特流长度：%d bit\n', length(tx_bits_after_source));


%% =========================
%  5. 信道编码（预留接口）
%% =========================

if use_channel_coding
    %%待写
    tx_bits_after_channel = channel_encode(tx_bits_after_source);
    fprintf('已启用信道编码。\n');
else
    tx_bits_after_channel = tx_bits_after_source;
    fprintf('未启用信道编码。\n');
end

fprintf('信道编码后比特流长度：%d bit\n', length(tx_bits_after_channel));


%% =========================
%  6. BPSK调制
%% =========================

% 将0/1比特映射为BPSK符号
% 这里规定：
% 0 -> -1
% 1 -> +1
tx_symbols = bpsk_mod(tx_bits_after_channel);


%% =========================
%  7. 通过AWGN信道
%% =========================

% 在发送信号上加入高斯白噪声
rx_symbols = awgn(tx_symbols, snr_db, 'measured');


%% =========================
%  8. BPSK解调
%% =========================

% 判决规则：
% 大于0判为1，小于等于0判为0
rx_bits_after_channel = bpsk_demod(rx_symbols);


%% =========================
%  9. 信道译码
%% =========================

if use_channel_coding
    % 待写
    rx_bits_after_source = channel_decode(rx_bits_after_channel);
    fprintf('已完成信道译码。\n');
else
    rx_bits_after_source = rx_bits_after_channel;
end


%% =========================
% 10. 信源译码
%% =========================

if use_source_coding
    % 待写
    rx_bits_recovered = source_decode(rx_bits_after_source);
    fprintf('已完成信源译码。\n');
else
    rx_bits_recovered = rx_bits_after_source;
end


%% =========================
% 11. 长度对齐处理
%% =========================

% 由于后续加入信源编码/信道编码后，
% 译码得到的比特长度可能和原始长度不完全一致，
% 这里先强制截取到原始长度，便于恢复图像和计算BER。
%
% 注意：
% 如果后续你们使用变长码（如哈夫曼），
% 更规范的做法是保存原始长度信息，并严格按协议恢复。
if length(rx_bits_recovered) < original_bit_len
    error('恢复后的比特流长度不足，无法重构原图像。');
else
    rx_bits_recovered = rx_bits_recovered(1:original_bit_len);
end


%% =========================
% 12. 重构图像
%% =========================

% 将恢复后的比特流重新转换为图像
img_rec = bits_to_image(rx_bits_recovered, img_size);

% 显示恢复图像
figure;
imshow(img_rec);
title(['恢复图像, SNR = ', num2str(snr_db), ' dB']);


%% =========================
% 13. 计算误码率 BER
%% =========================

% 比较原始比特流与恢复比特流之间的差异
ber = calc_ber(tx_bits_original, rx_bits_recovered);

fprintf('当前SNR = %.2f dB 时，BER = %.6f\n', snr_db, ber);


%% =========================
% 14. 原图与恢复图对比显示
%% =========================

figure;
subplot(1,2,1);
imshow(img);
title('原始图像');

subplot(1,2,2);
imshow(img_rec);
title(['恢复图像, BER = ', num2str(ber)]);