clc; clear; close all;
addpath(genpath('src'));

tic;

%% Hamming-only channel coding experiment
% Variables:
% - SNR
% - Hamming code parameters n, k
% Metrics:
% - BER: bit error rate after decoding
% - CER / FER: codeword error rate and frame error rate
% - Correction success rate: proportion of errored codewords corrected
% - Error weight distribution: weight of channel errors per codeword
% - Effective transmission efficiency: code rate * (1 - BER)

rng(1);

%% Parameters
img_path = fullfile('256256标准灰度图像测试集', '256', 'lena256.bmp');
snr_values = 0:2:12;
hamming_configs = [7, 4; 15, 11];  % [n, k]
num_trials = 20;

base_result_dir = 'results';
run_name = ['hamming_only_', datestr(now, 'yyyymmdd_HHMMSS')];
result_dir = fullfile(base_result_dir, run_name);
if ~exist(result_dir, 'dir')
    mkdir(result_dir);
end

log_path = fullfile(result_dir, 'console_output.txt');
diary(log_path);
cleanup_obj = onCleanup(@() diary('off')); %#ok<NASGU>

fprintf('Hamming-only experiment\n');
fprintf('结果保存目录：%s\n', result_dir);
fprintf('输入图像：%s\n', img_path);
fprintf('SNR 遍历范围：%s dB\n', mat2str(snr_values));
fprintf('Hamming 码参数：\n');
for cfg_idx = 1:size(hamming_configs, 1)
    fprintf('  n = %d, k = %d\n', hamming_configs(cfg_idx, 1), hamming_configs(cfg_idx, 2));
end
fprintf('重复试验次数：%d\n\n', num_trials);

%% Load image and convert to bits
img = imread(img_path);
if ndims(img) == 3
    img = rgb2gray(img);
end
img = uint8(img);
img_size = size(img);
original_bits = image_to_bits(img);
original_bit_len = numel(original_bits);

imwrite(img, fullfile(result_dir, 'original.png'));

summary_rows = {};
summary_idx = 0;

%% Run experiments for each Hamming configuration
for cfg_idx = 1:size(hamming_configs, 1)
    n = hamming_configs(cfg_idx, 1);
    k = hamming_configs(cfg_idx, 2);
    [code_rate, tx_bits, pad_len] = prepare_hamming_stream(original_bits, n, k);
    encoded_bit_len = numel(tx_bits);
    block_count = encoded_bit_len / n;
    effective_raw_rate = original_bit_len / encoded_bit_len;
    tx_symbols = bpsk_mod(tx_bits);
    original_padded_bits = [original_bits, zeros(1, pad_len)];
    original_data_blocks = reshape(original_padded_bits, k, []).';

    fprintf('\n========== Hamming (n=%d, k=%d) ==========' , n, k);
    fprintf('\n');
    fprintf('理论码率: %.6f, 实际传输效率: %.6f\n', code_rate, effective_raw_rate);
    fprintf('编码后比特数: %d\n', encoded_bit_len);
    fprintf('分块数: %d, 补零数: %d\n\n', block_count, pad_len);

    for snr_idx = 1:numel(snr_values)
        snr_db = snr_values(snr_idx);
        fprintf('SNR = %.2f dB\n', snr_db);

        sum_ber = 0;
        sum_cer = 0;
        sum_fer = 0;
        sum_correction_rate = 0;
        total_weight_hist = zeros(1, 4);

        for trial = 1:num_trials
            rx_symbols = awgn(tx_symbols, snr_db, 'measured');
            rx_bits = bpsk_demod(rx_symbols);

            % codeword-level errors before decoding
            tx_blocks = reshape(tx_bits, n, []).';
            rx_blocks = reshape(rx_bits, n, []).';
            error_weights = sum(xor(tx_blocks, rx_blocks), 2);
            block_errors = error_weights > 0;
            cer_trial = sum(block_errors) / block_count;
            sum_cer = sum_cer + cer_trial;
            total_weight_hist = total_weight_hist + histcounts(error_weights, [-0.5, 0.5, 1.5, 2.5, inf]);

            decoded_padded_bits = hamming_decode(rx_bits, n, k, original_bit_len + pad_len);
            decoded_bits = decoded_padded_bits(1:original_bit_len);
            sum_ber = sum_ber + calc_ber(original_bits, decoded_bits);
            if any(decoded_bits ~= original_bits)
                sum_fer = sum_fer + 1;
            end

            decoded_blocks = reshape(decoded_padded_bits, k, []).';
            block_success = all(decoded_blocks == original_data_blocks, 2);
            error_block_indices = find(block_errors);
            if isempty(error_block_indices)
                correction_rate_trial = 1.0;
            else
                correction_rate_trial = sum(block_success(error_block_indices)) / numel(error_block_indices);
            end
            sum_correction_rate = sum_correction_rate + correction_rate_trial;
        end

        avg_ber = sum_ber / num_trials;
        avg_cer = sum_cer / num_trials;
        avg_fer = sum_fer / num_trials;
        avg_correction_success = sum_correction_rate / num_trials;
        effective_rate = effective_raw_rate * (1 - avg_ber);

        summary_idx = summary_idx + 1;
        summary_rows(summary_idx, :) = { ...
            n, k, snr_db, code_rate, effective_raw_rate, avg_ber, avg_cer, avg_fer, ...
            avg_correction_success, effective_rate, total_weight_hist(1), total_weight_hist(2), ...
            total_weight_hist(3), total_weight_hist(4)};

        recovered_img = bits_to_image(decoded_bits, img_size);
        recovered_path = fullfile(result_dir, sprintf('recovered_n%d_k%d_snr_%g_dB.png', n, k, snr_db));
        compare_path = fullfile(result_dir, sprintf('compare_n%d_k%d_snr_%g_dB.png', n, k, snr_db));
        imwrite(recovered_img, recovered_path);
        save_compare_figure(img, recovered_img, n, k, snr_db, avg_ber, avg_cer, avg_fer, avg_correction_success, compare_path);

        fprintf('平均 BER = %.6e, CER = %.6f, FER = %.6f, 纠错成功率 = %.6f\n', ...
            avg_ber, avg_cer, avg_fer, avg_correction_success);
        fprintf('误重分布 [0,1,2,>=3] = [%d, %d, %d, %d]\n', total_weight_hist);
        fprintf('有效传输效率 = %.6f\n\n', effective_rate);
    end
end

%% Save summary
header = { ...
    'n', 'k', 'SNR_dB', 'CodeRate', 'RawRate', 'BER', 'CER', 'FER', ...
    'CorrectionSuccessRate', 'EffectiveTransmissionEfficiency', ...
    'Weight0_count', 'Weight1_count', 'Weight2_count', 'Weight3plus_count'};
summary_path = fullfile(result_dir, 'hamming_metrics_summary.csv');
writecell([header; summary_rows], summary_path);

save(fullfile(result_dir, 'hamming_experiment_results.mat'), ...
    'summary_rows', 'header', 'snr_values', 'hamming_configs', 'num_trials', 'img_path');

save_metric_curves(summary_rows, result_dir);

fprintf('结果已保存：%s\n', summary_path);
fprintf('控制台日志：%s\n', log_path);
fprintf('耗时：%.2f 秒\n', toc);

%% Local functions
function [code_rate, encoded_bits, pad_len] = prepare_hamming_stream(bits, n, k)
    [encoded_bits, pad_len] = hamming_encode(bits, n, k);
    code_rate = k / n;
end

function save_compare_figure(img, recovered_img, n, k, snr_db, ber, cer, fer, correction_rate, save_path)
    fig = figure('Visible', 'off');
    subplot(1, 2, 1);
    imshow(img);
    title('原始图像');

    subplot(1, 2, 2);
    imshow(recovered_img);
    title(sprintf('恢复图像 n=%d,k=%d SNR=%.1f dB', n, k, snr_db));

    annotation('textbox', [0.05, 0.01, 0.9, 0.1], 'String', sprintf('BER=%.4e, CER=%.4f, FER=%.4f, 纠错成功率=%.4f', ber, cer, fer, correction_rate), 'EdgeColor', 'none', 'HorizontalAlignment', 'center', 'FontSize', 10);
    exportgraphics(fig, save_path, 'Resolution', 150);
    close(fig);
end

function save_metric_curves(rows, result_dir)
    unique_configs = unique(cell2mat(rows(:, 1:2)), 'rows');
    for i = 1:size(unique_configs, 1)
        n = unique_configs(i, 1);
        k = unique_configs(i, 2);
        mask = cell2mat(rows(:, 1)) == n & cell2mat(rows(:, 2)) == k;
        config_rows = rows(mask, :);
        snr = cell2mat(config_rows(:, 3));
        bers = cell2mat(config_rows(:, 6));
        cers = cell2mat(config_rows(:, 7));
        fers = cell2mat(config_rows(:, 8));
        rates = cell2mat(config_rows(:, 10));

        fig = figure('Visible', 'off');
        subplot(2, 1, 1);
        semilogy(snr, bers, '-o', 'LineWidth', 1.5);
        hold on;
        semilogy(snr, cers, '-s', 'LineWidth', 1.5);
        semilogy(snr, fers, '-^', 'LineWidth', 1.5);
        grid on;
        xlabel('SNR / dB');
        ylabel('Error Rate');
        title(sprintf('Hamming (n=%d,k=%d) Error Rates', n, k));
        legend('BER', 'CER', 'FER', 'Location', 'southwest');

        subplot(2, 1, 2);
        plot(snr, rates, '-d', 'LineWidth', 1.5);
        grid on;
        xlabel('SNR / dB');
        ylabel('Effective Rate');
        title('Effective Transmission Efficiency');

        save_path = fullfile(result_dir, sprintf('metric_curves_n%d_k%d.png', n, k));
        exportgraphics(fig, save_path, 'Resolution', 150);
        close(fig);
    end
end
