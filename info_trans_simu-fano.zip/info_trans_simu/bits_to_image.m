function img = bits_to_image(bits, img_size)
    % 高效将比特流重构为图像矩阵
    bits_reshaped = reshape(bits, 8, []).';
    bin_str = char(bits_reshaped + '0');
    img_1d = bin2dec(bin_str);
    img = uint8(reshape(img_1d, img_size));
end