function symbols = bpsk_mod(bits)
    % 0 映射为 -1， 1 映射为 +1
    symbols = 2 * bits - 1; 
end