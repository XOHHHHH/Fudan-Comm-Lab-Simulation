function [decoded_bits, corrected_codewords] = hamming_decode(received_bits, n, k, total_data_bits)
%HAMMING_DECODE Decode a Hamming(n,k) bit stream, correcting single-bit errors.
%   If total_data_bits is provided, the decoded output is truncated to that length.

bits = normalize_bits(received_bits);
if isempty(bits)
    decoded_bits = zeros(1, 0);
    corrected_codewords = zeros(0, n);
    return;
end

if mod(numel(bits), n) ~= 0
    error('hamming_decode:InvalidLength', 'Received bit stream length must be a multiple of %d.', n);
end

m = n - k;
parity_positions = 2 .^ (0:m-1);
code_blocks = reshape(bits, n, []).';
num_blocks = size(code_blocks, 1);

syndromes = zeros(num_blocks, m);
for i = 1:m
    positions = bitget(1:n, i) == 1;
    syndromes(:, i) = mod(sum(code_blocks(:, positions), 2), 2);
end

error_positions = sum(syndromes .* (2 .^ (0:m-1)), 2);
corrected_codewords = code_blocks;
for idx = 1:num_blocks
    if error_positions(idx) > 0
        corrected_codewords(idx, error_positions(idx)) = 1 - corrected_codewords(idx, error_positions(idx));
    end
end

data_positions = setdiff(1:n, parity_positions);
decoded_data = reshape(corrected_codewords(:, data_positions).', 1, []);
if nargin >= 4 && ~isempty(total_data_bits) && total_data_bits < numel(decoded_data)
    decoded_bits = decoded_data(1:total_data_bits);
else
    decoded_bits = decoded_data;
end

decoded_bits = double(decoded_bits);
end

function bits = normalize_bits(input_bits)
bits = double(input_bits(:).');
if any(bits ~= 0 & bits ~= 1)
    error('hamming_decode:InvalidInput', 'Input must be a 0/1 bit stream.');
end
end