function bits = bpsk_demod(symbols)
    % 大于 0 判决为 1，否则为 0
    bits = double(symbols > 0); 
end