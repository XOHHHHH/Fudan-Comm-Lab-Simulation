clc; clear; close all;
%% =========================
%  信息论课程项目主程序 (费诺压缩 + 硬判决卷积码 专用版)
%% =========================

%% =========================
%  1. 参数设置
%% =========================
img_path = 'boat256.bmp';
% 建议测试点：因为硬判决比软判决差 2dB，所以建议测 SNR = 5, 6, 7
snr_db = 7; 
use_source_coding = true;
use_channel_coding = true;

%% =========================
%  2. 读取图像
%% =========================
img = imread(img_path);
if ndims(img) == 3
    img = rgb2gray(img);
end
img_size = size(img);

%% =========================
%  3. 图像转比特流
%% =========================
tx_bits_original = image_to_bits(img);
original_bit_len = length(tx_bits_original);
fprintf('==============================================\n');
fprintf('原始比特流长度：%d bit\n', original_bit_len);

%% =========================
%  4. 信源编码 (费诺码)
%% =========================
if use_source_coding
    [tx_bits_after_source, fano_dict] = source_encode(tx_bits_original); 
    fprintf('已启用信源编码 (费诺压缩)。\n');
else
    tx_bits_after_source = tx_bits_original;
    fano_dict = []; 
    fprintf('未启用信源编码。\n');
end

%% =========================
%  5. 信道编码 (卷积码)
%% =========================
if use_channel_coding
    tx_bits_after_channel = channel_encode(tx_bits_after_source);
    fprintf('已启用信道编码 (卷积码)。\n');
else
    tx_bits_after_channel = tx_bits_after_source;
end

%% =========================
%  6. BPSK调制
%% =========================
% 0 -> -1, 1 -> +1
tx_symbols = 2 * tx_bits_after_channel - 1; 

%% =========================
%  7. 通过AWGN信道
%% =========================
rx_symbols = awgn(tx_symbols, snr_db, 'measured');

%% =========================
%  8. 提取硬信息 (强行一刀切)
%% =========================
% 因为发送端 1 映射为 +1，0 映射为 -1
% 这里做最简单粗暴的判决：大于0就是1，小于等于0就是0
rx_bits_after_channel = rx_symbols > 0; 

%% =========================
%  9. 信道译码 (Viterbi 硬判决译码)
%% =========================
if use_channel_coding
    % 把切好的 0 和 1 喂给译码器
    rx_bits_after_source = channel_decode(rx_bits_after_channel);
    
    % --- 补充硬判决专属：信道 BER 统计 ---
    % 统计经过信道后，尚未译码前的纯物理误码率
    channel_err_count = sum(tx_bits_after_channel ~= rx_bits_after_channel);
    channel_ber = channel_err_count / length(tx_bits_after_channel);
    fprintf('已完成信道译码 (Viterbi 硬判决生效)。\n');
    fprintf('【辅助指标】译码前物理信道误码率 (信道BER) = %.6f\n', channel_ber);
else
    rx_bits_after_source = rx_bits_after_channel;
end

%% =========================
% 10. 信源译码 (费诺解码)
%% =========================
if use_source_coding
    rx_bits_recovered = source_decode(rx_bits_after_source, fano_dict); 
    fprintf('已完成信源译码。\n');
else
    rx_bits_recovered = rx_bits_after_source;
end

%% =========================
% 11. 长度对齐处理 (变长码防崩溃容错机制)
%% =========================
if length(rx_bits_recovered) < original_bit_len
    fprintf('\n【观察现象】：因信道残余误码导致费诺码失步，恢复的比特流缩水了 %d bit。\n', original_bit_len - length(rx_bits_recovered));
    fprintf('正在自动补零以完成破损图像重构...\n');
    pad_zeros = zeros(original_bit_len - length(rx_bits_recovered), 1);
    rx_bits_recovered = [rx_bits_recovered(:); pad_zeros];
    
elseif length(rx_bits_recovered) > original_bit_len
    fprintf('\n【观察现象】：因信道残余误码导致费诺码失步，恢复的比特流膨胀了。\n');
    fprintf('正在自动截断多余比特...\n');
    rx_bits_recovered = rx_bits_recovered(1:original_bit_len);
end

%% =========================
% 12. 重构图像
%% =========================
img_rec = bits_to_image(rx_bits_recovered, img_size);

%% =========================
% 13. 计算所有大作业评价指标 (BER, PER, PSNR, R_total)
%% =========================
fprintf('\n================ 最终性能报告 ================\n');
R_total = original_bit_len / length(tx_bits_after_channel);
fprintf('系统传输效率 R_total = %.4f\n', R_total);

ber = calc_ber(tx_bits_original, rx_bits_recovered);

img_vector = double(img(:));
img_rec_vector = double(img_rec(:));
total_pixels = length(img_vector);
per = sum(img_vector ~= img_rec_vector) / total_pixels;

mse_val = sum((img_vector - img_rec_vector).^2) / total_pixels;
if mse_val == 0
    psnr_val = Inf; 
else
    psnr_val = 10 * log10((255^2) / mse_val);
end

fprintf('当前 SNR = %.2f dB 时：\n', snr_db);
fprintf('  最终系统 BER = %.6f\n', ber);
fprintf('  像素错误率 PER  = %.6f\n', per);
fprintf('  峰值信噪比 PSNR = %.2f dB\n', psnr_val);
fprintf('==============================================\n');

%% =========================
% 14. 原图与恢复图对比显示
%% =========================
figure('Name', ['费诺+卷积硬判决 - SNR: ', num2str(snr_db), 'dB']);
subplot(1,2,1);
imshow(img);
title('原始图像');
subplot(1,2,2);
imshow(img_rec);
if psnr_val == Inf
    title('恢复图像 (完美重构)');
else
    title(['恢复图像 (PSNR = ', num2str(psnr_val, '%.2f'), ' dB)']);
end