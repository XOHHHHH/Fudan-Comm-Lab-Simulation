function rx_sig = add_awgn_noise(tx_sig, snr_db)
    % 纯手写 AWGN (加性高斯白噪声) 信道
    % 替代 toolbox 中的 awgn(tx_sig, snr_db, 'measured')
    
    % 1. 测量实际发送信号的平均功率 (对应 'measured' 功能)
    % 功率 = 信号幅值的平方的平均值
    sig_power = mean(abs(tx_sig).^2);
    
    % 2. 根据信噪比公式推算目标噪声功率
    % 公式: SNR_dB = 10 * log10(P_sig / P_noise)
    % 反推: P_noise = P_sig / 10^(SNR_dB / 10)
    snr_linear = 10^(snr_db / 10);
    noise_power = sig_power / snr_linear;
    
    % 3. 生成高斯白噪声序列
    % randn() 生成的是均值为 0，方差(功率)为 1 的标准正态分布序列
    % 将其乘以噪声功率的平方根（即标准差），即可得到目标噪声
    noise = sqrt(noise_power) * randn(size(tx_sig));
    
    % 4. 信号在信道中叠加噪声
    rx_sig = tx_sig + noise;
end